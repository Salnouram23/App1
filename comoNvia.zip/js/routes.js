angular.module('app.routes', [])

.config(function($stateProvider, $urlRouterProvider) {

  // Ionic uses AngularUI Router which uses the concept of states
  // Learn more here: https://github.com/angular-ui/ui-router
  // Set up the various states which the app can be in.
  // Each state's controller can be found in controllers.js
  $stateProvider
    

      .state('tabsController.iSEGUNIDAF', {
    url: '/Accueil',
    views: {
      'tab1': {
        templateUrl: 'templates/iSEGUNIDAF.html',
        controller: 'iSEGUNIDAFCtrl'
      }
    }
  })

  .state('tabsController.iSEGUNIDAF2', {
    url: '/apropos',
    views: {
      'tab1': {
        templateUrl: 'templates/iSEGUNIDAF2.html',
        controller: 'iSEGUNIDAF2Ctrl'
      }
    }
  })

  .state('tabsController', {
    url: '/page1',
    templateUrl: 'templates/tabsController.html',
    abstract:true
  })

  .state('tabsController.iSEGUNIDAF3', {
    url: '/inscription',
    views: {
      'tab1': {
        templateUrl: 'templates/iSEGUNIDAF3.html',
        controller: 'iSEGUNIDAF3Ctrl'
      }
    }
  })

  .state('tabsController.iSEGUNIDAF4', {
    url: '/seconnecter',
    views: {
      'tab1': {
        templateUrl: 'templates/iSEGUNIDAF4.html',
        controller: 'iSEGUNIDAF4Ctrl'
      }
    }
  })

$urlRouterProvider.otherwise('/page1/Accueil')


});